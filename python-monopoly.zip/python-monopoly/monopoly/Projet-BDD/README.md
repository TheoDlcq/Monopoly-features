Coucou les loulous <3
smehli

jèm pa html jprf python tu coco le kho

lien canva : https://www.canva.com/design/DAG5-Ef_DU8/jxrUeum9_0hgN8xj74oelQ/edit