# Dictionnaire de Données - Projet TOUTLA

**Version:** 1.0  
**Date:** 2025-11-28  
**Projet:** Système d'information librairie TOUTLA

---

## LIVRE

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| ISBN | VARCHAR(17) | 17 | PK, NOT NULL, UNIQUE | Identifiant unique du livre (ISBN-10 ou ISBN-13) |
| titre | NVARCHAR(500) | 500 | NOT NULL | Titre du livre |
| resume | NVARCHAR(MAX) | - | NULL | Résumé du livre |
| prix | DECIMAL(10,2) | 10,2 | NOT NULL, >= 0 | Prix de vente en euros |
| dateParution | DATE | - | NOT NULL | Date de première publication |
| langue | VARCHAR(50) | 50 | NOT NULL | Langue du livre |
| format | VARCHAR(50) | 50 | NOT NULL | Format (Broché, Poche, Relié, E-book) |

**Relations:** Editeur (1), Rayon (1), Auteurs (N), Sélections (N), Stock (N), Ventes (N), Commandes (N), Réservations (N), Déplacements (N)

---

## AUTEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idAuteur | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(100) | 100 | NOT NULL | Nom de famille |
| prenom | NVARCHAR(100) | 100 | NOT NULL | Prénom |
| dateNaissance | DATE | - | NULL | Date de naissance |

**Relations:** Livres (N), Événements (N)

---

## EDITEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idEditeur | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(200) | 200 | NOT NULL, UNIQUE | Nom de la maison d'édition |
| adresse | NVARCHAR(500) | 500 | NULL | Adresse postale |
| contact | NVARCHAR(200) | 200 | NULL | Email, téléphone |

**Relations:** Livres (N)

---

## RAYON

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idRayon | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(100) | 100 | NOT NULL, UNIQUE | Nom du rayon |
| description | NVARCHAR(500) | 500 | NULL | Description du rayon |

**Relations:** Responsable (1), Livres (N), Stocks (N), Vendeurs (N), Déplacements source/destination (N)

---

## RESPONSABLE_RAYON

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idResponsable | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(100) | 100 | NOT NULL | Nom |
| prenom | NVARCHAR(100) | 100 | NOT NULL | Prénom |
| email | VARCHAR(255) | 255 | NOT NULL, UNIQUE | Email professionnel |
| telephone | VARCHAR(20) | 20 | NULL | Téléphone |

**Relations:** Rayon (1)

---

## STOCK

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idStock | INT | 4 | PK, IDENTITY | Identifiant unique |
| quantite | INT | 4 | NOT NULL, >= 0 | Quantité disponible |
| seuilAlerte | INT | 4 | NOT NULL, >= 0 | Seuil de réapprovisionnement |
| dateDerniereMaj | DATETIME | 8 | NOT NULL, DEFAULT GETDATE() | Date de dernière mise à jour |

**Relations:** Livre (1), Rayon (1)

---

## CLIENT

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idClient | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(100) | 100 | NOT NULL | Nom ou raison sociale |
| prenom | NVARCHAR(100) | 100 | NULL | Prénom (particulier) |
| email | VARCHAR(255) | 255 | NULL | Email |
| telephone | VARCHAR(20) | 20 | NULL | Téléphone |
| typeClient | VARCHAR(20) | 20 | NOT NULL, IN ('Particulier','Professionnel') | Type de client |
| conditionsTarifaires | DECIMAL(5,2) | 5,2 | NULL, 0-100 | Remise % (professionnel) |

**Relations:** CarteFidelite (0..1), Ventes (N), Réservations (N)

---

## CARTE_FIDELITE

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idCarte | INT | 4 | PK, IDENTITY | Identifiant unique |
| numeroCarte | VARCHAR(20) | 20 | NOT NULL, UNIQUE | Numéro de carte visible |
| dateCreation | DATE | - | NOT NULL, DEFAULT GETDATE() | Date de création |
| points | INT | 4 | NOT NULL, DEFAULT 0, >= 0 | Points accumulés |

**Relations:** Client (1)

---

## VENDEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idVendeur | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(100) | 100 | NOT NULL | Nom |
| prenom | NVARCHAR(100) | 100 | NOT NULL | Prénom |
| email | VARCHAR(255) | 255 | NOT NULL, UNIQUE | Email professionnel |
| telephone | VARCHAR(20) | 20 | NULL | Téléphone |

**Relations:** Rayon (1), Ventes (N), Événements (N)

---

## VENTE

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idVente | INT | 4 | PK, IDENTITY | Identifiant unique |
| dateVente | DATETIME | 8 | NOT NULL, DEFAULT GETDATE() | Date et heure de vente |
| montantTotal | DECIMAL(10,2) | 10,2 | NOT NULL, >= 0 | Montant total en euros |
| modePaiement | VARCHAR(50) | 50 | NOT NULL | Espèces, Carte, Chèque, etc. |

**Relations:** Client (1), Vendeur (1), LignesVente (N)

---

## LIGNE_VENTE

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idLigneVente | INT | 4 | PK, IDENTITY | Identifiant unique |
| quantite | INT | 4 | NOT NULL, > 0 | Quantité vendue |
| prixUnitaire | DECIMAL(10,2) | 10,2 | NOT NULL, >= 0 | Prix unitaire au moment de la vente |
| montantLigne | DECIMAL(10,2) | 10,2 | NOT NULL, = quantite × prixUnitaire | Montant de la ligne |

**Relations:** Vente (1), Livre (1)

---

## COMMANDE_FOURNISSEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idCommande | INT | 4 | PK, IDENTITY | Identifiant unique |
| dateCommande | DATE | - | NOT NULL, DEFAULT GETDATE() | Date de commande |
| dateReceptionPrevue | DATE | - | NOT NULL, >= dateCommande | Date prévue de réception |
| statut | VARCHAR(50) | 50 | NOT NULL, DEFAULT 'En attente' | En attente, Confirmée, Livrée, etc. |

**Relations:** Fournisseur (1), LignesCommande (N)

---

## LIGNE_COMMANDE_FOURNISSEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idLigneCommande | INT | 4 | PK, IDENTITY | Identifiant unique |
| quantite | INT | 4 | NOT NULL, > 0 | Quantité commandée |
| prixUnitaire | DECIMAL(10,2) | 10,2 | NOT NULL, >= 0 | Prix unitaire d'achat |

**Relations:** CommandeFournisseur (1), Livre (1)

---

## FOURNISSEUR

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idFournisseur | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(200) | 200 | NOT NULL, UNIQUE | Nom ou raison sociale |
| adresse | NVARCHAR(500) | 500 | NULL | Adresse postale |
| contact | NVARCHAR(200) | 200 | NULL | Email, téléphone |

**Relations:** Commandes (N)

---

## RESERVATION

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idReservation | INT | 4 | PK, IDENTITY | Identifiant unique |
| dateReservation | DATE | - | NOT NULL, DEFAULT GETDATE() | Date de réservation |
| dateExpiration | DATE | - | NOT NULL, >= dateReservation | Date d'expiration |
| statut | VARCHAR(50) | 50 | NOT NULL, DEFAULT 'En attente' | En attente, Disponible, Récupérée, etc. |

**Relations:** Client (1), Livre (1)

---

## EVENEMENT

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idEvenement | INT | 4 | PK, IDENTITY | Identifiant unique |
| type | VARCHAR(50) | 50 | NOT NULL | Dédicace, Conférence, Rencontre, etc. |
| titre | NVARCHAR(200) | 200 | NOT NULL | Titre de l'événement |
| dateEvenement | DATETIME | 8 | NOT NULL, >= GETDATE() | Date et heure |
| salle | NVARCHAR(100) | 100 | NOT NULL | Salle ou zone |
| creneau | VARCHAR(50) | 50 | NOT NULL | Créneau horaire |
| nombrePlaces | INT | 4 | NULL, > 0 | Nombre de places (optionnel) |

**Relations:** Auteur (1), Vendeur (1)

---

## SELECTION_THEMATIQUE

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idSelection | INT | 4 | PK, IDENTITY | Identifiant unique |
| nom | NVARCHAR(200) | 200 | NOT NULL | Nom de la sélection |
| description | NVARCHAR(500) | 500 | NULL | Description |
| dateCreation | DATE | - | NOT NULL, DEFAULT GETDATE() | Date de création |

**Relations:** Livres (N)

---

## DEPLACEMENT

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idDeplacement | INT | 4 | PK, IDENTITY | Identifiant unique |
| dateDeplacement | DATE | - | NOT NULL, DEFAULT GETDATE() | Date du déplacement |
| quantite | INT | 4 | NOT NULL, > 0 | Quantité déplacée |
| raison | NVARCHAR(500) | 500 | NULL | Motif du déplacement |
| idRayonSource | INT | 4 | NOT NULL, FK | Rayon source |
| idRayonDestination | INT | 4 | NOT NULL, FK, != idRayonSource | Rayon destination |

**Relations:** Livre (1), Rayon source (1), Rayon destination (1)

---

## LIVRE_AUTEUR (Table d'association)

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idLivre | VARCHAR(17) | 17 | PK, FK → Livre(ISBN) | ISBN du livre |
| idAuteur | INT | 4 | PK, FK → Auteur(idAuteur) | Identifiant auteur |

**Relations:** Livre (1), Auteur (1)

---

## LIVRE_SELECTION (Table d'association)

| Attribut | Type | Taille | Contraintes | Description |
|----------|------|--------|-------------|-------------|
| idLivre | VARCHAR(17) | 17 | PK, FK → Livre(ISBN) | ISBN du livre |
| idSelection | INT | 4 | PK, FK → SelectionThematique(idSelection) | Identifiant sélection |

**Relations:** Livre (1), SélectionThématique (1)

---

## Légende

- **PK:** Clé primaire
- **FK:** Clé étrangère
- **IDENTITY:** Auto-incrémenté
- **NOT NULL:** Obligatoire
- **UNIQUE:** Valeur unique
- **DEFAULT:** Valeur par défaut
- **CHECK:** Contrainte de validation
